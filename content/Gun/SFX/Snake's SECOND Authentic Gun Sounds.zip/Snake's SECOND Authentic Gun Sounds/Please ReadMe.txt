Hey, it's Snake! Thank you for downloading my SECOND Authentic Gun Sounds Pack!

You can download the FIRST pack here: https://f8studios.itch.io/snakes-authentic-gun-sounds
These sounds were made for Soldiers' Descent, the turn-based RPG with shooter elements: https://f8studios.itch.io/soldiers-descent
Join the Discord! https://discord.gg/FzBS7FCPtR